<!-- View Invoices Page From Database -->
<!-- In the works -->
<html>
    <head>
        <title>Invoices From Database</title>
        <link rel='stylesheet' type='text/css' href='../css/main.css' />
    </head>

    <body>
        <div id="wrapper-thank-you" style="width: 75%;">

            <div id="header">Invoices Stored In Database</div>

            <h1> Invoices: </h1>

            <p> Database Storage Coming Soon </p>

            <div >
                <input class="thanks-button" style="min-width:200px;" type="button" 
                       onclick="location.href = '../index.html';" 
                       value="Go Back To New Invoice Page" />
            </div>

        </div>

    </body>


</html>