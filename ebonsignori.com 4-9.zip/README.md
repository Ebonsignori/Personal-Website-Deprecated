# Ebonsignori.com 
*A site with content by Evan Bonsignori*

## Goals:
- [ ] Blog With Bootstrap and Python
- [ ] Add Menu Navigation to each page
- [ ] Star wars intro to first page- volume option off/on transition to corner
- [ ] SEO

## Fix:
- [ ] Useless sites default load page
- [ ] Load background image before page

## Add:
- [ ] Usless Games: Space game
- [ ] Credits to footer

## Ideas:
- Guided Tour

## Blog Ideas:
- Political News site ranking using page scanner and bias phrase selecting in two categories (right/left leaning)
- Micro vs Macro life improvement
- Onion Like Articles and fun stuff
- Categories: Political, self improvement, CS tutorials, comedy 
