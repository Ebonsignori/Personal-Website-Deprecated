<?php
$server = 'localhost';
$user = 'eb3465';
$pwd = '2Ev6VneHwQbQ';
$db = 'invoicestorage';
?>